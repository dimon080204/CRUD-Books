This is my .net core Web API learning project. It allows to do CRUD operations with books data. 

Database is PostgreSQL. Connection information is in WebApi\DataAccess\Extensions.cs class.