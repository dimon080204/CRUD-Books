﻿using DataAccess;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace BusinessLogic
{
    internal class BookService(IBookRepository bookRepository) : IBookService
    {
        public async Task<Book> CreateAsync(Book newBook, CancellationToken cancellationToken = default) //string title, string author, DateOnly publishedDate, string genre, CancellationToken cancellationToken = default
        {
            //var newBook = new Book
            //{
            //    Title = title,
            //    Author = author,
            //    PublishedDate = publishedDate,
            //    Genre = genre
            //};

            try
            {
                var createdBook = await bookRepository.CreateAsync(newBook, cancellationToken);
                return createdBook;
            }
            catch (Exception ex)
            {
                // Handle exceptions (e.g., log them)
                throw new InvalidOperationException("An error occurred while creating the book.", ex);
            }
        }

        public async Task DeleteAsync(int id, CancellationToken cancellationToken = default)
        {
            try
            {
                var bookToDelete = await bookRepository.GetByIdAsync(id, cancellationToken);
                await bookRepository.DeleteAsync(bookToDelete, cancellationToken);
            }
            catch (Exception ex)
            {
                throw new KeyNotFoundException($"Book with ID {id} not found.", ex);
            }
        }

        public async Task<Book?> GetByIdAsync(int id, CancellationToken cancellationToken = default)
        {
            try
            {
                return await bookRepository.GetByIdAsync(id, cancellationToken);
            }
            catch (Exception ex)
            {
                // Handle exceptions (e.g., log them)
                throw new InvalidOperationException($"An error occurred while retrieving the book with ID {id}.", ex);
            }
        }

        public async Task<Book?> UpdateAsync(int id, Book updatedBook, CancellationToken cancellationToken = default)
        {
            updatedBook.Id = id; // Ensure the ID is set for the update

            try
            {
                return await bookRepository.UpdateAsync(updatedBook, cancellationToken);
            }
            catch (Exception ex)
            {
                // Handle exceptions (e.g., log them)
                throw new InvalidOperationException("An error occurred while updating the book.", ex);
            }
        }
    }
}
