﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess
{
    public static class Extensions
    {
        public static IServiceCollection AddDataAccess(this IServiceCollection serviceCollection)
        {
            serviceCollection.AddScoped<IBookRepository, BookRepository>();
            serviceCollection.AddDbContext<AppContext>(b =>
            {
                b.UseNpgsql("Host=localhost;Database=BookStore;Username=postgres;Password=1234");
                // Change the connection string as needed
                // dotnet ef migrations add "InitN" --startup-project WebApi/WebApi.csproj --project DataAccess/DataAccess.csproj
                // dotnet ef database update --startup-project WebApi/WebApi.csproj
            });
            return serviceCollection;
        }
    }
}
