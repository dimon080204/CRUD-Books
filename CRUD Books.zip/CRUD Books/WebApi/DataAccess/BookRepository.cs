﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess
{
    internal class BookRepository(AppContext context) : IBookRepository
    {
        public async Task<Book> CreateAsync(Book book, CancellationToken cancellationToken = default)
        {
            await context.Books.AddAsync(book, cancellationToken);
            await context.SaveChangesAsync(cancellationToken);
            return book;
        }

        public async Task DeleteAsync(Book book, CancellationToken cancellationToken = default)
        {
            context.Books.Remove(book);
            await context.SaveChangesAsync(cancellationToken);
        }

        public async Task<Book?> GetByIdAsync(int id, CancellationToken cancellationToken = default)
        {
            return await context.Books.FirstOrDefaultAsync(b => b.Id == id, cancellationToken);
        }

        public async Task<Book?> UpdateAsync(Book book, CancellationToken cancellationToken = default)
        {
            context.Books.Update(book);
            await context.SaveChangesAsync(cancellationToken);
            return book;
        }
    }
}
