﻿using System;
using System.ComponentModel.DataAnnotations; // Это важно для ValidationAttribute

public class NotFutureDateAttribute : ValidationAttribute
{
    protected override ValidationResult IsValid(object value, ValidationContext validationContext)
    {
        // Проверяем, является ли значение DateOnly (ваш случай) или DateTime
        if (value is DateOnly dateOnlyValue)
        {
            // Проверяем, что дата не в будущем
            if (dateOnlyValue > DateOnly.FromDateTime(DateTime.Today)) // Сегодняшняя дата
            {
                return new ValidationResult(GetErrorMessage());
            }
        }
        else
        {
            // Если тип данных не поддерживается атрибутом
            return new ValidationResult("Invalid data type for date validation.");
        }

        return ValidationResult.Success;
    }

    private string GetErrorMessage()
    {
        return ErrorMessage ?? "Date cannot be in the future.";
    }
}