﻿using BusinessLogic;
using DataAccess;
using Microsoft.AspNetCore.Mvc;

namespace WebApi.Controllers
{
    [ApiController]
    [Route("Book")]
    public class BookController(IBookService bookService) : ControllerBase
    {
        [HttpPost]
        public async Task<IActionResult> CreateBookAsync([FromBody] Book book) // string title, string author, DateOnly publishedDate, string genre
        {
            var createdBook = await bookService.CreateAsync(book);
            return CreatedAtRoute("GetBookByIdRoute", new { id = createdBook.Id }, createdBook);
        }

        [HttpGet("{id:int}", Name = "GetBookByIdRoute")]
        public async Task<ActionResult<Book>> GetBookAsync([FromRoute] int id)
        {
            try
            {
                var book = await bookService.GetByIdAsync(id);
                return Ok(book);
            }            
            catch
            {
                return NotFound($"Book with ID {id} not found.");
            }
            
        }

        [HttpPut("{id:int}")]
        public async Task<IActionResult> UpdateBookAsync([FromRoute] int id, [FromBody] Book book)
        {
            try
            {
                var updatedBook = await bookService.UpdateAsync(id, book);
                return Ok(updatedBook);
            }
            catch
            {
                return NotFound($"Book with ID {id} not found.");
            }
        }

        [HttpDelete("{id:int}")]
        public async Task<IActionResult> DeleteBookAsync([FromRoute] int id)
        {
            try
            {
                await bookService.DeleteAsync(id);
                return NoContent();
            }
            catch (KeyNotFoundException ex)
            {
                return NotFound(ex.Message);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }
    }
}
